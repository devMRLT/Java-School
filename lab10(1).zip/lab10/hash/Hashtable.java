package hash;
import java.util.*;
import java.lang.Math;

public abstract class Hashtable<T> {
  protected int capacity = 0;
  private List<String> keys = null;
  private List<T> values = null;

  private int probeCount = 0;

  public int getProbeCount() {
    return this.probeCount;
  }

  public void resetProbeCount() {
    this.probeCount = 0;
  }

  public Hashtable(int capacity) {
    this.keys = new ArrayList<String>();
    for (int i = 0; i < capacity; i++) {
      this.keys.add(null);
    }
    this.values = new ArrayList<T>();
    for (int i = 0; i < capacity; i++) {
      this.values.add(null);
    }
    this.capacity = capacity;
  }

  public int hash(String key) {
    int sum = 0;
    for (int i = 0; i < key.length(); i++) {
      sum += (int)key.charAt(i);
    }
    return sum % capacity;
  }

  public abstract int rehash(int previousHash);

  public void insert(String key, T value) {
    //linear probing
    LinearHashTable hash = new LinearHashTable;
    hash.rehash();
    this.probeCount++;
    System.out.println("Probe count Linear: " +getProbeCount());
    resetProbeCount();
    //quad probing
    QuadraticHashTable hash2 = new QuadraticHashTable;
    hash2.rehash();
    this.probeCount++;
    System.out.println("Probe Count Quad: " + getProbeCount());
    resetProbeCount();
  }
  //for linear probing
  abstract class LinearHashTable{
      public abstract int rehash(int previousHash){
        //declare the arrayIndex var and the countEmpty spaces for loop
        int arrIndex,countEmpty = 0;
        arr = new ArrayList<String>();//declare an array list
        arrIndex = hash(key);//create the hash
        if(arr.get(arrIndex) == ""){
          arr.get(arrIndex) = this.value;
        }else{
          while(arr.get(countEmpty) != "")
            countEmpty++;
          arr.get(countEmpty) = this.value;
        }
      }
  }
  //for quadratic probing
  abstract class QuadraticHashTable{
    public int j = 0;//declare j as zero to start
    //this method increases j
    public int jIncrease(){return j++;}
    //this method sets j back to zero
    public int jReset(){return j=0;}
    //this method inserts the hash into the array list
    public abstract int rehash(int previousHash, String key){
      int arrIndex = ((int)key + Math.pow(2, j)) % capacity; //formula for quad probing
      arr = new ArrayList<String>();//declare an array list
      if(arr.get(arrIndex) == ""){
          arr.get(arrIndex) = this.value;//insert the value into the array list
          jReset();//resets the j counter to zero
      }else{
        jIncrease();//increases the j value to try again at inserting the hash
        rehash();//will recursively call this function till it can add to the array list
      }
    }
  }
}
